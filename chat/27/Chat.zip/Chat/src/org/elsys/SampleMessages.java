package org.elsys;

public final class SampleMessages {
	public static final Message[] messages = new Message[] {
			new Message("Lorem", "Lorem ipsum dolor sit amet, consectetur adipiscing elit."),
			new Message("Ipsum", "Vestibulum est orci, ultricies in tincidunt eu, convallis in risus."),
			new Message("Lorem", "Donec in dolor ornare enim iaculis commodo. Donec eu tellus cursus, fermentum mi eget, placerat leo."),
			new Message("Ipsum", "Donec vel molestie orci. Donec ut enim eros. Vivamus sed ultrices nibh, a vulputate nulla. Aliquam iaculis at diam non sollicitudin."),
			new Message("Lorem", "Phasellus a justo interdum lectus molestie blandit vitae quis nunc."),
			new Message("Ipsum", "Mauris eget viverra orci."),
			new Message("Ipsum", "Nulla quis nunc non erat tincidunt tincidunt tempus eu lectus."),
			new Message("Lorem", "Cras nec orci quis urna efficitur bibendum."),
			new Message("Ipsum", "Aliquam faucibus sit amet urna ut bibendum. Integer sed nibh egestas, dictum dolor ac, imperdiet velit. Donec et risus interdum, porta risus eu, consequat diam."),
			new Message("Ipsum", "Morbi mauris risus, maximus sed augue non, cursus egestas arcu. Aliquam felis arcu, suscipit a lectus vitae, tincidunt scelerisque leo."),
			new Message("Lorem", "Phasellus pretium faucibus erat, id blandit nisl elementum in."),
			new Message("Ipsum", "Suspendisse rhoncus ornare augue, sit amet consectetur lacus mollis et."),
			new Message("Lorem", "Sed vitae ultricies felis."),
			new Message("Ipsum", "Mauris augue arcu, lacinia congue aliquet id, laoreet sit amet massa. Phasellus ornare arcu nec tincidunt vulputate."),
			new Message("Lorem", "Pellentesque eget sagittis nisl, eget bibendum leo. "),
			new Message("Ipsum", "Suspendisse potenti. Integer id eleifend turpis."),
			new Message("Lorem", "Cras a nisi in tortor ultrices sollicitudin nec eget augue. Pellentesque lobortis, massa non hendrerit bibendum, nunc mauris ullamcorper lorem, id elementum ex elit vitae nibh."),
			new Message("Ipsum", "Vestibulum feugiat tempus turpis, eu gravida enim pellentesque sit amet. Integer ultrices felis quis dapibus feugiat. "),
			new Message("Ipsum", "Duis fermentum tristique odio, id eleifend mi gravida sed. Donec vitae consequat lectus, vel feugiat dui. Ut eu laoreet tortor. Proin ac ligula eget justo fringilla finibus. Morbi a luctus nulla, pellentesque luctus elit."),
			new Message("Lorem", "Vivamus pharetra scelerisque bibendum.")
	};
}
